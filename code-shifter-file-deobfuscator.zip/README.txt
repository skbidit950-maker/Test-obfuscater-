Code Shifter — File Import & Deobfuscation Helpers

Usage:
1. Open index.html in a modern browser.
2. Select a text/source file with Choose a source file.
3. Tap Load file into input or Detect selected file.
4. Run Auto-detect obfuscator or Try safe common decoding.
5. Tap Download deobfuscated result to save the current result.

Local-only: the page reads files in your browser and does not upload them.
Limitations: this can try common text encodings and identify heuristics. It cannot universally deobfuscate arbitrary obfuscators, compiled bytecode, custom VMs, or encrypted payloads. Never run unknown code as part of analysis.
