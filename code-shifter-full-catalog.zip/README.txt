Code Shifter — Obfuscation Lab

Open index.html in a modern browser. It runs locally and does not upload pasted code.
Tabs:
- Encoding & cleanup
- Full method catalog (includes the supplied A01-A19 and B1-B9 methods)
- Static defensive analyzer
- Limits & safe workflow

Note: this is a learning and defensive inspection tool, not a universal obfuscator/deobfuscator.
