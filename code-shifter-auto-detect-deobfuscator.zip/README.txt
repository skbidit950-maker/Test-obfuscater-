Code Shifter — Auto-detect & common deobfuscation helpers

Open index.html in a modern browser. The page processes pasted code locally and does not upload it.
New features:
- Heuristic auto-detection of common encodings and obfuscation indicators
- Safe common decoding attempts for Base32, Base64, and hex text
- Download the current result as deobfuscated-result.txt

Limitations:
- This is not a universal deobfuscator. Custom VM bytecode, runtime-patched instruction streams, encrypted payloads, and unknown packers require format-specific analysis.
- Detection can produce false positives or miss techniques.
- The analyzer never executes pasted code.
